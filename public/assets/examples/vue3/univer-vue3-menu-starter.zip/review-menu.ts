import type { FUniver } from '@univerjs/core/facade'
import '@univerjs/sheets/facade'
import '@univerjs/ui/facade'

export function registerReviewMenus(univerAPI: FUniver) {
  const approve = () => {
    const sheet = univerAPI.getActiveWorkbook()?.getActiveSheet()
    if (!sheet) return
    sheet.getRange('A1').setValue('Approved')
  }

  univerAPI.createMenu({
    id: 'review.quick-approve',
    title: 'Quick approve',
    icon: 'ProtectIcon',
    action: approve,
  }).appendTo('ribbon.start.others')

  const approveItem = univerAPI.createMenu({
    id: 'review.approve',
    title: 'Approve',
    icon: 'ProtectIcon',
    action: approve,
  })

  const actions = univerAPI.createSubmenu({
    id: 'review.actions',
    title: 'Actions',
  }).addSubmenu(approveItem)

  univerAPI.createSubmenu({
    id: 'review.root',
    title: 'Review',
  }).addSubmenu(actions)
    .appendTo(['contextMenu.mainArea', 'contextMenu.others'])
}
