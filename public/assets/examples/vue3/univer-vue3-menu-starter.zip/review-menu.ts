import { Inject, Injector, Plugin } from '@univerjs/core'
import { DropdownMenu } from '@univerjs/design'
import { ComponentManager, IconManager, IMenuManagerService, MenuItemType, RibbonStartGroup } from '@univerjs/ui'
import { createElement } from 'react'

function ReviewIcon() {
  return createElement('svg', {
    viewBox: '0 0 24 24', width: 16, height: 16,
    fill: 'none', stroke: 'currentColor', strokeWidth: 2,
    'aria-hidden': true, 'data-review-icon': true,
  }, createElement('path', { d: 'M5 12l4 4L19 6' }))
}

export class ReviewMenuPlugin extends Plugin {
  static override pluginName = 'REVIEW_MENU_PLUGIN'

  constructor(
    private readonly _config: { approve: () => void },
    @Inject(Injector) protected override _injector: Injector,
  ) { super() }

  override onStarting() {
    const components = this._injector.get(ComponentManager)
    const icons = this._injector.get(IconManager)
    const ReviewMenu = () => createElement('span', {
      onClick: event => event.stopPropagation(),
    }, createElement(DropdownMenu, {
      items: [{ type: 'subItem', children: 'Actions', options: [
        { type: 'item', children: 'Approve', onSelect: this._config.approve },
      ] }],
      children: createElement('button', {
        type: 'button', 'data-review-trigger': true,
        style: { display: 'flex', alignItems: 'center', gap: 6, border: 0, background: 'transparent', color: 'inherit', cursor: 'pointer' },
      }, createElement(icons.get('review-icon')), 'Review'),
    }))
    this.disposeWithMe(components.register('review-menu', ReviewMenu))
    this.disposeWithMe(icons.register('review-icon', ReviewIcon))
    this._injector.get(IMenuManagerService).mergeMenu({
      [RibbonStartGroup.OTHERS]: {
        'review.root': {
          order: 0,
          menuItemFactory: () => ({
            id: 'review.root', type: MenuItemType.BUTTON,
            title: 'Review', label: 'review-menu',
          }),
        },
      },
    })
  }
}
