# Univer Vue 3 menu customization

Requires Node.js 22.18 or newer. All Univer packages use 1.3.0.

```bash
npm install
npm run dev
```

Open the Vite URL. Use the links in the demo header to switch between two examples. Each opens a new editor with A1 set to Draft.

## Application Facade

On Start, click Quick approve: A1 becomes Approved. You can also right-click a cell and choose Review → Actions → Approve. This example uses createMenu(), createSubmenu(), and appendTo(). ProtectIcon is a built-in icon. The nested menu is a context menu; the toolbar has one shortcut button.

## SDK Plugin

Open /?example=plugin, or click SDK Plugin. On Start, click Plugin approve: A1 becomes Approved by plugin. Undo restores Draft. The custom checkmark comes from IconManager registration. The plugin registers its own command and menu schema in onStarting(), matching the registration pattern used by the Sheets UI plugin. The data edit still uses the Facade API.

The plugin's menu ID is review-plugin.menu.approve; its command ID is review-plugin.command.approve. Configure visibility or disabled state by menu ID. Registering a plugin and using plugin-mode installation are different tasks; the latter also supports Facade APIs.

## Runtime menu configuration

Use Disable toolbar button to disable the example's toolbar action. It should not change A1 while disabled. Clear the checkbox to enable it. Use Hide toolbar button to remove and restore the same toolbar action. These Vue host controls call updateMenuConfig(); they are not part of the editor menu. In the Facade example, they affect the toolbar shortcut only, not the separate context-menu action.

Register each example once per editor. The host calls univer.dispose() on Vue unmount. The plugin owns its command and icon registrations through disposeWithMe(). mergeMenu() returns void; the menu schema shares the editor lifetime. This example does not demonstrate dynamically unloading a menu plugin from a live editor.

Run npm run build to typecheck and build this project.
