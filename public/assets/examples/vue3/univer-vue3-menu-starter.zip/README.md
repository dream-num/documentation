# Univer Vue 3 menus with Facade API

Requires Node.js 22.18 or newer.

```bash
npm install
npm run dev
```

Open the Vite URL. On Start, click Quick approve: A1 becomes Approved. Set A1 back to Draft, then right-click a cell and choose Review → Actions → Approve to run the same action from a nested context menu. On narrow screens the toolbar shortcut may be in the overflow menu.

The example uses createMenu(), createSubmenu(), and appendTo() through the public Facade API. ProtectIcon is a built-in icon. It does not register or access internal UI services. Register the menus once per editor; the Vue host calls univer.dispose() on unmount.

All Univer packages use 1.3.0. The nested menu in this versioned example is a context menu; the toolbar has a single shortcut button.

Run npm run build to typecheck and build this example.
