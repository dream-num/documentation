# Univer Vue 3 nested toolbar menu

Requires Node.js 22.18 or newer.

```bash
npm install
npm run dev
```

Open the Vite URL. On Start, open Review, hover Actions, and choose Approve. A1 changes to Approved. On narrow screens Review may be in the toolbar overflow menu.

The Vue host embeds Univer. A plugin registers a custom icon with IconManager and a React dropdown with ComponentManager because the editor UI uses React. The dropdown reuses @univerjs/design; Vue UI adapters are only needed when mounting Vue components inside the editor.

All Univer packages use 1.3.0. Do not register the plugin twice on one instance. The Vue host disposes the editor on unmount, releasing plugin-owned registrations.

Run `npm run build` to typecheck and build this example.
