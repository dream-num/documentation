import { CommandType, DependentOn, ICommandService, Inject, Injector, Plugin, UniverInstanceType } from '@univerjs/core'
import { UniverSheetsUIPlugin } from '@univerjs/sheets-ui'
import { IconManager, IMenuManagerService, MenuItemType, RibbonStartGroup } from '@univerjs/ui'
import { createElement } from 'react'

const APPROVE_COMMAND_ID = 'review-plugin.command.approve'
const APPROVE_MENU_ID = 'review-plugin.menu.approve'
const APPROVE_ICON_ID = 'review-plugin.icon.approve'

function ReviewIcon() {
  return createElement('svg', {
    viewBox: '0 0 24 24', width: 16, height: 16,
    fill: 'none', stroke: 'currentColor', strokeWidth: 2,
    'aria-hidden': true, 'data-review-plugin-icon': true,
  }, createElement('path', { d: 'M5 12l4 4L19 6' }))
}

@DependentOn(UniverSheetsUIPlugin)
export class ReviewPlugin extends Plugin {
  static override pluginName = 'REVIEW_PLUGIN'
  static override type = UniverInstanceType.UNIVER_SHEET

  constructor(
    private readonly _config: { approve: () => boolean },
    @Inject(Injector) protected override _injector: Injector,
    @ICommandService private readonly _commands: ICommandService,
    @IMenuManagerService private readonly _menus: IMenuManagerService,
    @Inject(IconManager) private readonly _icons: IconManager,
  ) { super() }

  override onStarting() {
    this.disposeWithMe(this._commands.registerCommand({
      id: APPROVE_COMMAND_ID,
      type: CommandType.COMMAND,
      handler: () => this._config.approve(),
    }))
    this.disposeWithMe(this._icons.register(APPROVE_ICON_ID, ReviewIcon))
    this._menus.mergeMenu({
      [RibbonStartGroup.OTHERS]: {
        [APPROVE_MENU_ID]: {
          order: 0,
          menuItemFactory: () => ({
            id: APPROVE_MENU_ID,
            commandId: APPROVE_COMMAND_ID,
            type: MenuItemType.BUTTON,
            title: 'Plugin approve',
            icon: APPROVE_ICON_ID,
          }),
        },
      },
    })
  }
}
