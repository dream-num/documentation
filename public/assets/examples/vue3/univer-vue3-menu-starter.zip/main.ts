import type { Univer } from '@univerjs/core'
import { UniverSheetsCorePreset } from '@univerjs/preset-sheets-core'
import sheetsEnUS from '@univerjs/preset-sheets-core/locales/en-US'
import { createUniver, LocaleType, mergeLocales } from '@univerjs/presets'
import { createApp, defineComponent, h, onBeforeUnmount, onMounted } from 'vue'
import { ReviewMenuPlugin } from './review-menu'
import '@univerjs/preset-sheets-core/lib/index.css'

const App = defineComponent({
  setup() {
    let univer: Univer | undefined
    onMounted(() => {
      const editor = createUniver({
        locale: LocaleType.EN_US,
        locales: { [LocaleType.EN_US]: mergeLocales(sheetsEnUS) },
        presets: [UniverSheetsCorePreset({ container: 'univer' })],
      })
      univer = editor.univer
      const univerAPI = editor.univerAPI
      univer.registerPlugin(ReviewMenuPlugin, {
        approve: () => {
          univerAPI.getActiveWorkbook()?.getActiveSheet()?.getRange('A1').setValue('Approved')
        },
      })
      univerAPI.createWorkbook({})
    })
    onBeforeUnmount(() => univer?.dispose())
    return () => h('div', { id: 'univer', style: { height: '100vh' } })
  },
})
createApp(App).mount('#app')
