import type { Univer } from '@univerjs/core'
import type { FUniver } from '@univerjs/core/facade'
import { UniverSheetsCorePreset } from '@univerjs/preset-sheets-core'
import sheetsEnUS from '@univerjs/preset-sheets-core/locales/en-US'
import { createUniver, LocaleType, mergeLocales } from '@univerjs/presets'
import { createApp, defineComponent, h, onBeforeUnmount, onMounted } from 'vue'
import { registerReviewMenus } from './review-menu'
import { ReviewPlugin } from './review-plugin'
import '@univerjs/preset-sheets-core/lib/index.css'

const App = defineComponent({
  setup() {
    const pluginExample = new URLSearchParams(location.search).get('example') === 'plugin'
    const menuId = pluginExample ? 'review-plugin.menu.approve' : 'review.quick-approve'
    let univer: Univer | undefined
    let api: FUniver | undefined
    const updateMenu = (key: 'disabled' | 'hidden', event: Event) => {
      api?.updateMenuConfig({ [menuId]: { [key]: (event.target as HTMLInputElement).checked } })
    }
    onMounted(() => {
      const editor = createUniver({
        locale: LocaleType.EN_US,
        locales: { [LocaleType.EN_US]: mergeLocales(sheetsEnUS) },
        presets: [UniverSheetsCorePreset({ container: 'univer' })],
      })
      univer = editor.univer
      const univerAPI = editor.univerAPI
      api = univerAPI
      if (pluginExample) {
        univer.registerPlugin(ReviewPlugin, {
          approve: () => {
            const sheet = univerAPI.getActiveWorkbook()?.getActiveSheet()
            if (!sheet) return false
            sheet.getRange('A1').setValue('Approved by plugin')
            return true
          },
        })
      } else {
        registerReviewMenus(univerAPI)
      }
      const workbook = univerAPI.createWorkbook({})
      workbook.getActiveSheet().getRange('A1').setValue('Draft')
    })
    onBeforeUnmount(() => univer?.dispose())
    return () => h('div', { style: { height: '100vh', display: 'flex', flexDirection: 'column' } }, [
      h('nav', {
        style: { display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '16px', padding: '12px', fontFamily: 'sans-serif', fontSize: '14px' },
      }, [
        h('strong', pluginExample ? 'SDK Plugin example' : 'Application Facade example'),
        h('a', { href: '?example=facade' }, 'Application Facade'),
        h('a', { href: '?example=plugin' }, 'SDK Plugin'),
        h('label', [h('input', { type: 'checkbox', onChange: (event: Event) => updateMenu('disabled', event) }), 'Disable toolbar button']),
        h('label', [h('input', { type: 'checkbox', onChange: (event: Event) => updateMenu('hidden', event) }), 'Hide toolbar button']),
      ]),
      h('div', { id: 'univer', style: { flex: '1', minHeight: '0' } }),
    ])
  },
})
createApp(App).mount('#app')
