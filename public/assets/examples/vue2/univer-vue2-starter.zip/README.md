# Univer Sheets with Vue 2

Verified with Node.js 26, Vue 2.7.16, and Vite 6.3.6.

Run `npm install`, then `npm run dev` and open the printed URL.

The Notebook total is 36. Change quantity from 3 to 4 and check that the total becomes 48.

Use `npm run build` for a production build.

For new applications, prefer Vue 3. For integration details, see https://docs.univer.ai/guides/sheets/getting-started/integrations/vue#vue-2x.
