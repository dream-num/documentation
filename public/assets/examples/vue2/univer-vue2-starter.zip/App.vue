<script>
import { UniverSheetsCorePreset } from '@univerjs/preset-sheets-core'
import UniverPresetSheetsCoreEnUS from '@univerjs/preset-sheets-core/locales/en-US'
import { createUniver, LocaleType, mergeLocales } from '@univerjs/presets'

import '@univerjs/preset-sheets-core/lib/index.css'

export default {
  mounted() {
    const { univer, univerAPI } = createUniver({
      locale: LocaleType.EN_US,
      locales: {
        [LocaleType.EN_US]: mergeLocales(
          UniverPresetSheetsCoreEnUS,
        ),
      },
      presets: [
        UniverSheetsCorePreset({
          container: this.$refs.container,
        }),
      ],
    })

    this.univerInstance = univer
    this.univerAPI = univerAPI

    const workbook = univerAPI.createWorkbook({})
    workbook.getActiveSheet().getRange('A1:D3').setValues([
      ['Item', 'Quantity', 'Unit price', 'Total'],
      ['Notebook', 3, 12, '=B2*C2'],
      ['Pen', 5, 2, '=B3*C3'],
    ])
  },
  beforeDestroy() {
    this.univerInstance?.dispose()
    this.univerInstance = null
    this.univerAPI = null
  },
}
</script>

<template>
  <div ref="container" style="height: 600px" />
</template>
